
//SCRIPT BY Praszxdd
//SCRIPT INI FREE JADI JANGAN DI JUAL PUQI 
// YT : @Prasszxd
// *`PROMOO!! SC BUG + BAHAN HOSTING`*
//> P.O JUSTIN V20 VIA TELE 35K VIA WA 50K
// SC EVIL CRASHER V6 25K 
//> SC AZURA VIA TELE 10K NO ENC
//> RESSELER AZURA 40K
//> SC AZURA VIA WA 20K FREE UP 1×
//> SC EVIL CRASHER P.O V5 25K
//> SC JUSTIN V19 40K
//> SC JUSTIN V18 35K
//> PANEL UNLI 10K PRIVAT NO DELAY
//> SC BOT BUG + MD 20K NO ENC
//> ADP 15K PERMA
//> NOKOS? ALL BEDA HARGA
// Pembelian digw all dpet free pane unli
//MINAT? wa.me/+6285713569137

const chalk = require("chalk")
const fs = require("fs")
//aumto presence update
global.autoTyping = true //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.wlcm = true
global.autokickmorroco = false //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)
//===============SETTING MENU==================\\
global.thumbnail = 'https://qu.ax/bTwwg.jpg'
global.ig = 'lanzz879' 
global.yt = ''
global.ttowner = ''
global.ownername = '🩸Lanzdev🩸'
global.owner = ['6285710277684'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6285710277684'
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
global.namaowner2 = 'Lanzxy'
global.ownernumber1 = '6285817591970'
//========================setting Payment=====================\\
global.nodana = '6285887389254' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = '6285817591970' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = '' // KOSONG KAN JIKA TIDAK ADA
//==================setting Payment Name===========================\\
global.andana = 'more' // KOSONG KAN JIKA TIDAK ADA
global.angopay = ' ' // KOSONG KAN JIKA TIDAK ADA
global.anovo = 'gtw' // KOSONG KAN JIKA TIDAK ADA
//==================setting bot===========================\\
global.botname = "𝑨𝒛𝒖𝒓𝒂𝒂𝑴𝒖𝒍𝒕𝒊𝑫𝒆𝒗𝒊𝒄𝒆"
global.ownernumber = '6285710277684'
global.botnumber = '6285817591970'
global.ownername = 'Lanzxy'
global.ownerNumber = ["6285710277684@s.whatsapp.net"]
global.ownerweb = "gd"
global.websitex = ""
global.wagc = ""
global.saluran = ""
global.themeemoji = '🪀'
global.wm = "Lanz"
global.botscript = 'gada mnding nyeppong titi gw nih' //script link
global.packname = "Sticker By"
global.author = "\n\n\n\n\nCreate by Ryou Azuraa\nNo hape/wa : 6285713569137"
global.creator = "6285710277684@s.whatsapp.net"
//======================== CPANEL FITUR ===========================\\
global.domain = '-' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
global.eggsnya = '16' // id eggs yang dipakai
global.location = '1' // id location
//=========================================================//
global.apiDigitalOcean = "-"
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//
global.mess = {
   wait: "Sabar Anj Ga sabar Gw Ewe Mau?",
   success: "Nih Anak Ngen",
   on: "ON",
   off: "OFF",
   query: {
       text: "Tulisannya mana, Kak? Aku kan gak bisa baca pikiran 😅",
       link: "Link-nya mana, Kak? Jangan pelit dong! 😜",
   },
   error: {
       fitur: "Oops! Ada yang rusak nih, Kak. Coba lapor ke developer biar bisa diperbaiki. 🙏",
   },
   only: {
       group: "FITUR CUMA DIGRUB GBLK",
       private: "CUMA PRIVAT",
       owner: "LU BUKAN PRASSZXDGANTENGGBLK",
       admin: "Hanya bisa dipakai sama admin grup, Kak. Mungkin lain kali ya 😉",
       badmin: "Waduh! Bot-nya belum jadi admin grup nih. Tolong kasih jabatan dulu, Kak 😅",
       premium: "Kak, ini fitur premium loh! Biar bisa pake, beli dulu ke owner yaa 😎 (Ketik .owner buat info lebih lanjut)",
   }
}
//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['','!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
